#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contatinhos.h"

void criar(t_lista *lista){
    lista->primeiro = NULL;
}

static t_apontador pesquisa_apontador(t_lista *lista, t_chave chave[]){
    t_apontador aux; //= (t_apontador) malloc(sizeof(t_no));
        if(aux == NULL)
            return NULL;

    aux = lista->primeiro;
    while(aux != NULL){
        if(strcmp(aux->elemento.nome , chave) == 0 )
            return aux;
        aux = aux->proximo; 
    }

    return NULL;
}

void inserir(t_lista *lista, t_elemento elemento){
    t_apontador novo = (t_apontador) malloc(sizeof(t_no));
    if(novo == NULL)
        return;
  //printf("entrei no inserir");

    t_apontador aux = pesquisa_apontador(lista, elemento.nome);
    if(aux!=NULL){
      //printf("t_apontador: %s", aux->elemento.nome);
      printf("Contatinho ja inserido\n");
      return;
    }
  
    novo->elemento = elemento; //elemento do apontador novo recebe o elemento que quero inserir
    novo->proximo = lista->primeiro;
    //se chave do novo for maior que chave do novo->prox
    lista->primeiro = novo;
    
  
}

void remover(t_lista *lista, t_chave chave[]){
    //achar a posicao
    //achar a posicao do anterior
    // o anterior aponta pro que o elemento.proximo apontava
    //dar free no elemento

    t_apontador P = lista->primeiro; //anterior
    if(P == NULL) return;

    //removendo o primeiro elemento, se esse for o caso
    if (strcmp(P->elemento.nome, chave)==0) { 
  		lista->primeiro = lista->primeiro->proximo;
  		free(P);
  		return;
  	}

    //percorre o vetor com P ate que seu proximo seja o que procura
    //salva essa posicao em um auxiliar
    //aponta o proixmo do p pro seu proximo do proximo atual-->remover-->fim o atual aponta pra fim, que eh
    // o proximo de remover, que eh o proximo do atual
	while(P->proximo != NULL) {
		if (strcmp(P->proximo->elemento.nome, chave)==0) {
			t_apontador aux = P->proximo;
			P->proximo = P->proximo->proximo;
			free(aux);
			return;
		}
		P = P->proximo;
	}

  printf("Operacao invalida: contatinho nao encontrado");

    // t_apontador pos = pesquisa_apontador(lista,chave); //o que eu quero
    // P = lista->primeiro;
    // while(P->proximo != pos){ //enquanto meu aux P nao estiver apontando pra posicao que eu quero
    //     P = P->proximo; 
    // }


    // P->proximo = pos->proximo;
    // free(pos);

    // return SUCESSO;

}
void pesquisar_contatinho(t_lista *lista,t_chave chave[]){
    t_apontador aux = pesquisa_apontador(lista, chave);
  if(aux == NULL){ //se o elemento nao existe pra ser alterado
    printf("Contatinho nao encontrado\n");
    return;
  }
    t_elemento e = pesquisa_apontador(lista,chave) -> elemento;     printf("Contatinho encontrado: telefone %s", e.telefone);
}


t_elemento pesquisar(t_lista *lista,t_chave chave[]){
    return pesquisa_apontador(lista,chave) -> elemento;   
}


void alterar(t_lista *lista, t_elemento novo_elemento){
   t_apontador aux = pesquisa_apontador(lista, novo_elemento.nome);
  if(aux == NULL){ //se o elemento nao existe pra ser alterado
    printf("Operacao invalida: contatinho nao encontrado\n");
    return;
  }
  
  // aux->elemento.telefone = novo_elemento.telefone;
  t_elemento elemento = pesquisar(lista, novo_elemento.nome);
  remover(lista, elemento.nome);
  inserir(lista, novo_elemento);

}





  
void imprimir(t_lista *lista){
    t_apontador flecha;
    flecha = lista->primeiro;

    while(flecha != NULL){
        printf("%s %s\n", flecha->elemento.nome, flecha->elemento.telefone);
        flecha = flecha->proximo;
    }
  
}