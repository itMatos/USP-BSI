#include <stdio.h>
#include "teste.h"

void teste() {
  printf("teste");
}