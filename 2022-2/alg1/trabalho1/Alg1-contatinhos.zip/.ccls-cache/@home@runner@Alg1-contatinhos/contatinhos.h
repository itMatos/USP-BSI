#ifndef CONTATINHOS_H
    #define CONTATINHOS_H
 
    #define LISTA_CHEIA -2
    #define LISTA_VAZIA -1
    #define SUCESSO 100
    #define JA_EXISTE 1
    #define ERRO 0  

    typedef char t_chave[11];
    typedef struct t_no *t_apontador;

    typedef struct{
        t_chave nome;
        char telefone[10];
    }t_elemento;

    typedef struct t_no{
        t_elemento elemento;
        t_apontador proximo;
    }t_no;


    typedef struct{   // a lista eh so o apontador pro primeiro
        t_apontador primeiro;
        //t_apontador ultimo;
    }t_lista;

    // -----------------------------------------------------------------------------------

    void criar(t_lista *lista);
    void inserir(t_lista *lista, t_elemento elemento);
    void remover(t_lista *lista, t_chave chave[]);
    void pesquisar_contatinhos(t_lista *lista,t_chave chave[]);
    t_elemento pesquisar(t_lista *lista,t_chave chave[]);
    void alterar(t_lista *lista, t_elemento novo_elemento);
    //int vazia(t_lista *lista);
    //int cheia(t_lista *lista);
    void imprimir(t_lista *lista);


#endif 