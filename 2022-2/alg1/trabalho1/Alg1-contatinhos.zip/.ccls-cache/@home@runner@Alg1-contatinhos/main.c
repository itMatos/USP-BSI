#include <stdio.h>
#include "contatinhos.h"

int main(void) {
  t_lista minha_lista_legal;
  t_elemento meu_elemento_legal;

  printf("CRIEI A LISTAAAAA!!! %d%%\n", criar(&minha_lista_legal));

  for(int i=0; i<3; i++){
    scanf("%s", meu_elemento_legal.nome);
    scanf("%s", meu_elemento_legal.telefone);
  
    printf("inserir: %d%%\n", inserir(&minha_lista_legal, meu_elemento_legal));
    
    }

  imprimir(&minha_lista_legal);
  
}
