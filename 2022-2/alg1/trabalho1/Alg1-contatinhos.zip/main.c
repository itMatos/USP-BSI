#include <stdio.h>
#include "contatinhos.h"

int main(void) {
  t_lista meus_contatinhos;
  t_elemento meu_contatinho;
  char opcao, temp;

  criar(&meus_contatinhos);


  scanf("%c", &opcao);
  while(opcao!=48){
    switch(opcao){
      case 'I':
        scanf("%s %s", meu_contatinho.nome, meu_contatinho.telefone);
        inserir(&meus_contatinhos, meu_contatinho);
        break;
      case 'P':
        scanf("%s", meu_contatinho.nome);
        pesquisar_contatinho(&meus_contatinhos, meu_contatinho.nome);
        break;
      case 'R':
        scanf("%s",  meu_contatinho.nome);
        remover(&meus_contatinhos, meu_contatinho.nome);
        break;
      case 'A':
        scanf("%s %s", meu_contatinho.nome, meu_contatinho.telefone);
        alterar(&meus_contatinhos, meu_contatinho);
        break;
      case 'Q':
        imprimir(&meus_contatinhos);
        break;
      default:
        printf("Operacao invalida");
    }
    scanf("%c", &temp);
    scanf("%c", &opcao);
  }
  
}
